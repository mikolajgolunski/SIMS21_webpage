﻿/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'hu', {
	bold: 'Félkövér',
	italic: 'Dőlt',
	strike: 'Áthúzott',
	subscript: 'Alsó index',
	superscript: 'Felső index',
	underline: 'Aláhúzott'
} );
