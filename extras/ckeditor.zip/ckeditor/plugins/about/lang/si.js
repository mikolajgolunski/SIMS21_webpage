﻿/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'si', {
	copy: 'පිටපත් අයිතිය සහ පිටපත් කිරීම;$1 .සියලුම හිමිකම් ඇවිරිණි.',
	dlgTitle: 'CKEditor ගැන විස්තර',
	help: 'උදව් සඳහා $1 ',
	moreInfo: 'බලපත්‍ර තොරතුරු සදහා කරුණාකර අපගේ විද්‍යුත් ලිපිනයට පිවිසෙන්න:',
	title: 'CKEditor ගැන විස්තර',
	userGuide: 'CKEditor භාවිතා කිරීම පිළිබඳ '
} );
