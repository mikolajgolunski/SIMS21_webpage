﻿/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'uk', {
	copy: 'Copyright &copy; $1. Всі права застережено.',
	dlgTitle: 'Про CKEditor',
	help: 'Перевірте $1 для допомоги.',
	moreInfo: 'Щодо інформації з ліцензування завітайте на наш сайт:',
	title: 'Про CKEditor',
	userGuide: 'Інструкція Користувача для CKEditor'
} );
