﻿/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'oc', {
	copy: 'Copyright &copy; $1. Totes los dreits reservats.',
	dlgTitle: 'A prepaus de CKEditor',
	help: 'Consultar $1 per obténer d\'ajuda.',
	moreInfo: 'Per las informacions de licéncia, visitatz nòstre site web :',
	title: 'A prepaus de CKEditor',
	userGuide: 'Guida de l\'utilizaire CKEditor (en anglés)'
} );
